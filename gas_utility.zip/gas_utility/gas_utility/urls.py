# gas_utility_service/urls.py

from django.contrib import admin
from django.urls import path, include
from consumer_services import views as consumer_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('django.contrib.auth.urls')),
    path('submit-request/', consumer_views.submit_service_request, name='submit_request'),
    path('request-tracking/', consumer_views.request_tracking, name='request_tracking'),
]
